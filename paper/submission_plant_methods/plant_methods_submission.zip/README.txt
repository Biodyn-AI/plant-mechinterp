Plant Methods submission — LaTeX source package
=================================================

Manuscript: Mechanistic Interpretability of a Plant Genomic Foundation
Model: Data Probes, Causal Interventions, and Motif-Grounded Features

Author: Ihor Kendiukhov, Department of Computer Science,
University of Tübingen, Germany.  ORCID 0000-0001-5342-1499.

Article type: Methodology.

Files in this package
---------------------

  main.tex            LaTeX source of the manuscript.
  references.bib      BibTeX bibliography.
  figures/            PNG figures (300 DPI) referenced by main.tex:
                        figures/probing_region_type.png   (Figure 1)
                        figures/cross_species_v2.png      (Figure 2)
                        figures/sae_training.png          (Figure 3)
                        figures/head_ablations_splice.png (Figure 4)
  cover_letter.pdf    Cover letter to the Editor.
  main.pdf            Pre-compiled PDF of the manuscript (18 pages).

How to recompile
----------------

Requirements: a standard TeX Live (2020+) distribution with pdflatex,
bibtex, natbib, authblk, enumitem, hyperref, booktabs, setspace.  All are
standard packages.

  pdflatex main.tex
  bibtex main
  pdflatex main.tex
  pdflatex main.tex

Bibliography style: unsrtnat (Vancouver-style numbered, natbib-
compatible).  Part of the natbib package in TeX Live.

Reproducibility
---------------

All experiments are reproducible from the code at

  https://github.com/Biodyn-AI/aido-mechinterp

with a permanent archival snapshot at

  https://doi.org/10.5281/zenodo.18665058 .

Stochastic pipelines use fixed seeds (0, 1, 2).  Data sources are pinned
(TAIR10, Araport11, Ensembl Plants release 58, EPDnew v1, JASPAR 2024
CORE plantae, PlantTFDB 5.0).
